<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
    <link rel="stylesheet" href="removeemployee.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>

<div class="removeempform">
            <h1>Remove Emloyee</h1>
        <form action="removeemployeeinput.php" method="post">

        <div class = "enterempid">
        Enter Employee ID :<input type="number" name="ID" id="vieworder" required>
     
     <br><br>

     <input class="submit" type="submit" value="Remove Employee" name="submit">
        </div>
    
    
    </form>
        </div>
    

    
</body>
</html>