<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="octa.css">
    <link rel="stylesheet" href="inputt.css">
</head>
<body>

    <!-- Header -->
    <header class="header">
        <!-- Div for logo -->
    <div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>
    <!-- Div for navbar -->
    <div class="mid">
        <ul class="navbar">
            <li><a href="home.php" >Home</a></li>
            <li><a href="about.php" >About</a></li>
            <li><a href="orderform.php" >Order</a></li>
            <li><a href="contactus.php" >Contact Us</a></li>
            <li><a href="login.php" >Login</a></li>
        </ul>
    </div>
    <!-- Div for button -->
    <div class="right">
        <button class="btn"><a href="https://web.facebook.com/OCTA-Herbal-Shampoo-102603767915346/">Like us on Facebook</a></button>
    </div>
    </header>
    
   

<!-- Data Base Connection -->


<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){

  // <!-- Taking Data From Form -->
  

if(isset($_POST['submit'])){
  $first_name = $_POST['customerfirstname'];
  $last_name = $_POST['customerlastname'];
  $cnic = $_POST['customercnic'];
  $email = $_POST['customeremail'];
  $number = $_POST['customernumber'];
  $company_name = $_POST['customercompanyname'];
  $company_number = $_POST['companyphone'];
  $address = $_POST['customeraddress'];
  $date = $_POST['orderdate'];
  $no_of_small_bottles = $_POST['smallbottles'];
  $no_of_large_bottles = $_POST['largebottles'];
  $id = $_POST['id'];


// Checking Validity of form

  $total_quantity = $no_of_small_bottles + $no_of_large_bottles;
$total_price = ($no_of_small_bottles * 180) + ($no_of_large_bottles * 330);
$discount = ($no_of_small_bottles * 30) + ($no_of_large_bottles * 50);
$total_payable = $total_price - $discount;

 

}


}
else{ 
    echo "<p>Sorry Database Connection Failed</p>";
}    
echo '<br>';
?>

<!-- Inserting Data in Data Base-->

<?php

$is_present = FALSE;
$check_id = "select customer_id from customer";
$result_checkid = mysqli_query($conn,$check_id);

$num = mysqli_num_rows($result_checkid);

if($num > 0){
    // $row = mysqli_fetch_assoc($result_checkid);
    while($row = mysqli_fetch_assoc($result_checkid)){
        if($row['customer_id'] == $id){
            $is_present = TRUE;
            break;
        }
    }
}

if($is_present==TRUE){
  echo "<span>This ID is already registered!<br>Please Enter a different ID</span>";
}
else{
// Inserting data in customer table
$insert_customer = "INSERT INTO customer(customer_id, first_name, last_name, CNIC,address, email, phone, company_name, company_phone, product_id) VALUES ('$id', '$first_name', '$last_name', '$cnic', '$address', '$email', '$number', '$company_name', '$company_number', '1')";

$result_customer = mysqli_query($conn,$insert_customer);

if($result_customer == TRUE){
  // echo "Done";
}
else{
  echo 'data not inserted in customer because ->' . mysqli_error($conn);
}


// Inerting data in order table


$insert_order = "INSERT INTO `order_table` (`order_id`, `order_date`, `quantity`, `customer_id`, `product_id`) VALUES ('$id', '$date', '$total_quantity', '$id', '1')";

$result_order = mysqli_query($conn,$insert_order);

if($result_order == TRUE){
  // echo "Done order";
}
else{
  echo 'data is not inserted in order ->' . mysqli_error($conn);
}


// Inserting data in order_details table
$insert_orderdetails = "INSERT INTO `order_details` (`total_price`, `discount`, `total_payable`, `no_of_small_bottles`, `no_of_large_bottles`, `order_id`) VALUES ('$total_price', '$discount', '$total_payable', '$no_of_small_bottles', '$no_of_large_bottles', '$id')";
$result_orderdetails = mysqli_query($conn,$insert_orderdetails);
if($result_orderdetails ==TRUE){
  // echo "done order details";
}
else{
  echo 'data is not inserted in order details ->' . mysqli_error($conn);
}


if($result_orderdetails ==TRUE && $result_order ==TRUE && $result_customer ==TRUE){
  echo "<h2>Thanks! <br> Your order has been confirmed</h2>";
}

}
?>




</body>
</html>