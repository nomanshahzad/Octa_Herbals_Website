<?php

session_start();
//   echo "welcome";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>

<div class="admin">
        <div class="adminfunc"><a href="addemployee.php">Add Employee</a>  </div>
        <div class="adminfunc"><a href="removeemployee.php">Remove Employee</a></div>
        <div class="adminfunc"><a href="viewemp.php">View Employee Details</a></div>
        <div class="adminfunc"><a href="viewcustomer.php">View Customers</a>  </div>
        
   
    </div>

    
</body>
</html>