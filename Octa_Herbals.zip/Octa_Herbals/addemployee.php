<?php

session_start();
//   echo "welcome";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
    <link rel="stylesheet" href="addemployee.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>

<div class="form">
        <h1>Enter Employee Details</h1>
        <form action="inputaddemployee.php" method="post">
            <div class="firstname" >
              <p>  First Name  : <input type="text" name="empfirstname" required></p>
            </div>
            <div class="lastname">
                <p>     Last Name  : <input type="text" name="emplastname" required></p>
            </div>
            <div class="dob">
                <p>DOB : <input type="date" name="empdob" required></p>
            </div>
            <div class="cnic">
                <p>CNIC : <input type="number" name="empcnic" required></p>
            </div>
            <div class="salary">
                <p>Salary : <input type="number" name="empsalary" required></p>
            </div>
            <div class="hiredate">
                <p>Hire Date : <input type="date" name="emphiredate" required></p>
            </div>
            <div class="address">
                <p>Address : <input type="text" name="empaddress" required></p>
            </div>
            <div class="city" >
              <p>  City  : <input type="text" name="empcity" required></p>
              </div>
            <div class="email">
                <p>Email     :      <input type="email" name="empemail" required></p>
            </div>
            <div class="phone">
                <p>Phone No : <input type="tel" name="empnumber" required></p>
            </div>

            <div class="dept">
                <p>Department : <select name = "empdept" class = "empdept" required>
                    <option>Executive</option>
                    <option>marketing</option>
                    <option>IT</option>
                    <option>sweeper</option>

                </select></p>
            </div>
            
            
            
       
            
                 <input class="submit" type="submit" value="Submit Details" name="submit">
            

        </form>
       


    
</body>
</html>