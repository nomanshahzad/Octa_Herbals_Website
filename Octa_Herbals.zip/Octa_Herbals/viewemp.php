<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
    <link rel="stylesheet" href="viewemp.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>


<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    $view_emp = "select e.employee_id,e.first_name,e.last_name,e.dob,e.cnic,e.salary,e.hire_date,e.city,e.email,e.phone,d.department_name from employee e,department d where e.department_id = d.department_id";
    $result = mysqli_query($conn,$view_emp);

    $num = mysqli_num_rows($result);

    if($num > 0){
        echo"<h1>Employee details:</h1>";
        echo "<table>";
            echo "<tr>";
                echo "<th>Employee_id</th>";
                echo "<th>First Name</th>";
                echo "<th>Last Name</th>";
                echo "<th>DOB</th>";
                echo "<th>CNIC</th>";
                echo "<th>Salary</th>";
                echo "<th>Hire Date</th>";
                echo "<th>City</th>";
                echo "<th>Email</th>";
                echo "<th>Phone No#</th>";
                echo "<th>Department</th>";
            echo "</tr>";
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
                echo "<td>" . $row['employee_id'] . "</td>";
                echo "<td>" . $row['first_name'] . "</td>";
                echo "<td>" . $row['last_name'] . "</td>";
                echo "<td>" . $row['dob'] . "</td>";
                echo "<td>" . $row['cnic'] . "</td>";
                echo "<td>" . $row['salary'] . "</td>";
                echo "<td>" . $row['hire_date'] . "</td>";
                echo "<td>" . $row['city'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['phone'] . "</td>";
                echo "<td>" . $row['department_name'] . "</td>";
            echo "</tr>";
        }
    }
    else{
        echo "No Records";
    }
    

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';

?>

    
</body>
</html>