<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password);

if($conn == TRUE){
    echo "Connection was successfull";

}
else{ 
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
// creating database
$create_database = 'create Database Octa_Herbals';
$result = mysqli_query($conn,$create_database);
if($result == TRUE){
    echo 'database is successfully created';
}
else{
    echo 'database is not created beacause of error ->' . mysqli_error($conn);
}


?>