<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="inputaddemployee.css">
    <link rel="stylesheet" href="welcom.css">
   
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>

<!-- Data Base Connection -->


<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){

  // <!-- Taking Data From Form -->
  

if(isset($_POST['submit'])){
  $first_name = $_POST['empfirstname'];
  $last_name = $_POST['emplastname'];
  $dob = $_POST['empdob'];
  $cnic = $_POST['empcnic'];
  $salary = $_POST['empsalary'];
  $hire_date = $_POST['emphiredate'];
  $address = $_POST['empaddress'];
  $city = $_POST['empcity'];
  $email = $_POST['empemail'];
  $phone = $_POST['empnumber'];
  $department = $_POST['empdept'];
  $dept_id = 0;

  if($department=="Executive"){
      $dept_id = 1;
  }
  elseif($department=="marketing"){
    $dept_id = 2;
}
elseif($department=="IT"){
    $dept_id = 3;
}
elseif($department=="sweeper"){
    $dept_id = 4;
}
 

}
}
else{ 
    echo "<p>Sorry Database Connection Failed</p>";
}    
echo '<br>';
?>

<!-- Inserting Data in Database -->
<p>
<?php
$insert_employee = "INSERT INTO employee(first_name,last_name,dob,cnic,salary,hire_date,address,city,email,phone,department_id) VALUES ('$first_name','$last_name','$dob','$cnic','$salary','$hire_date','$address','$city','$email','$phone','$dept_id')";

$result = mysqli_query($conn,$insert_employee);
if($result==TRUE){
    echo "Record Added Successfully!";
}
else{
    echo "Record Not Added!";
}


?>
    </p>
</body>
</html>