<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
    <link rel="stylesheet" href="removeemployeeinput.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>

<!-- ----------------- -->
<?php
    $servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    if(isset($_POST['submit'])){
        $id_for_remove = $_POST['ID'];  
    }
    // echo $id_for_view;
    echo "<br>";
// Checking ID is present in table or not
    $is_present = FALSE;
    $check_id = "select employee_id from employee";
    $result_checkid = mysqli_query($conn,$check_id);

    $num = mysqli_num_rows($result_checkid);

    if($num > 0){
        // $row = mysqli_fetch_assoc($result_checkid);
        while($row = mysqli_fetch_assoc($result_checkid)){
            if($row['employee_id'] == $id_for_remove){
                $is_present = TRUE;
                break;
            }
        }
    }
}


if($is_present==TRUE){
    // deleting from order details
    $delete_employee = "delete from employee where employee_id=$id_for_remove";
    $result_employee = mysqli_query($conn,$delete_employee);
    if($result_employee == TRUE){
        echo "<p>Employee Removed Successfully</p>";
      }
      else{
        echo 'data not deleted from order details because ->' . mysqli_error($conn);
    }
}
else{
    echo "<p>Record Not Present</p>";
}
?>

    
</body>
</html>