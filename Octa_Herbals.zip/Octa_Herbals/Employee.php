<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    echo "Connection was successfull";

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
// creating database
$create_table = 'CREATE TABLE employee(employee_id INT NOT NULL AUTO_INCREMENT ,first_name VARCHAR(45) NOT NULL , last_name VARCHAR(45) NOT NULL , dob DATE NOT NULL , cnic INT(13) NOT NULL , salary INT NOT NULL , hire_date DATE NOT NULL , address VARCHAR(45) NOT NULL , city VARCHAR(45) NOT NULL , email VARCHAR(45) NOT NULL , phone INT NOT NULL , department_id INT NOT NULL , PRIMARY KEY (employee_id), UNIQUE (cnic), UNIQUE (email), UNIQUE (phone), CONSTRAINT FK_dept_id FOREIGN KEY (department_id)
REFERENCES department(department_id))';


$result = mysqli_query($conn,$create_table);
if($result == TRUE){
    echo 'Table is successfully created';
}
else{
    echo 'Table is not created beacause of error ->' . mysqli_error($conn);
}


?>