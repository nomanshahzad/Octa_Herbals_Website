<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="octa.css">
</head>
<body>

    <!-- Header -->
    <header class="header">
        <!-- Div for logo -->
    <div class="left">
    <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>
    <!-- Div for navbar -->
    <div class="mid">
        <ul class="navbar">
            <li><a href="home.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="orderform.php">Order</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>
    <!-- Div for button -->
    <div class="right">
    <button class="btn"><a href="https://web.facebook.com/OCTA-Herbal-Shampoo-102603767915346/">Like us on Facebook</a></button>
    </div>



    </header>
    <h3>you are on contact page</h3>
</body>
</html>