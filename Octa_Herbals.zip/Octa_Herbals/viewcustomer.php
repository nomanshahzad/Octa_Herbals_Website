<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="welcom.css">
    <link rel="stylesheet" href="viewcustomer.css">
</head>
<body>

<div class="welcome">
<div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>

<div class="mid">
<h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome!<br>You are logged in</h2>    
</div>


<div class="right">
        <button class="btn"><a href="login.php">Log out</a></button>
    </div>

</div>


<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    $view_customer = "select * from customer";
    $result = mysqli_query($conn,$view_customer);

    $num = mysqli_num_rows($result);

    if($num > 0){
        echo"<h1>Customers details:</h1>";
        echo "<table>";
            echo "<tr>";
                echo "<th>Customer_id</th>";
                echo "<th>First Name</th>";
                echo "<th>Last Name</th>";
                echo "<th>CNIC</th>";
                echo "<th>Address</th>";
                echo "<th>Email</th>";
                echo "<th>Phone No#</th>";
                echo "<th>Company Name</th>";
                echo "<th>Company Phone</th>";
            echo "</tr>";
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
                echo "<td>" . $row['customer_id'] . "</td>";
                echo "<td>" . $row['first_name'] . "</td>";
                echo "<td>" . $row['last_name'] . "</td>";
                echo "<td>" . $row['CNIC'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['phone'] . "</td>";
                echo "<td>" . $row['company_name'] . "</td>";
                echo "<td>" . $row['company_phone'] . "</td>";
            echo "</tr>";
        }
    }
    else{
        echo "No Records";
    }
    

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';

?>

    
</body>
</html>