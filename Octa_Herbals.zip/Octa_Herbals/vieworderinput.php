<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="octa.css">
    <link rel="stylesheet" href="vieworderinput.css">
</head>
<body>

    <!-- Header -->
    <header class="header">
        <!-- Div for logo -->
    <div class="left">
        <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>
    <!-- Div for navbar -->
    <div class="mid">
        <ul class="navbar">
            <li><a href="home.php" >Home</a></li>
            <li><a href="about.php" >About</a></li>
            <li><a href="orderform.php" >Order</a></li>
            <li><a href="contactus.php" >Contact Us</a></li>
            <li><a href="login.php" >Login</a></li>
        </ul>
    </div>
    <!-- Div for button -->
    <div class="right">
        <button class="btn"><a href="https://web.facebook.com/OCTA-Herbal-Shampoo-102603767915346/">Like us on Facebook</a></button>
    </div>

    </header>

    <h1>Your Order Details : </h1>

<?php
    $servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    if(isset($_POST['submit'])){
        $id_for_view = $_POST['ID'];  
    }
    // echo $id_for_view;
    echo "<br>";
// Checking ID is present in table or not
    $is_present = FALSE;
    $check_id = "select customer_id from customer";
    $result_checkid = mysqli_query($conn,$check_id);

    $num = mysqli_num_rows($result_checkid);

    if($num > 0){
        // $row = mysqli_fetch_assoc($result_checkid);
        while($row = mysqli_fetch_assoc($result_checkid)){
            if($row['customer_id'] == $id_for_view){
                $is_present = TRUE;
                break;
            }
        }
    }

// Fetching data from tables
            if($is_present==TRUE){
                // fetching from customer
                $get_customer = "select * from customer where customer_id = $id_for_view";
                $result_customer = mysqli_query($conn,$get_customer);
                if($result_customer == TRUE){
                    $row_customer = mysqli_fetch_assoc($result_customer);
                  }
                  else{
                    echo 'data not fetched from customer because ->' . mysqli_error($conn);
                  }


                // fetching from order
                $get_order = "select * from order_table where order_id = $id_for_view";
                $result_order = mysqli_query($conn,$get_order);
                if($result_order == TRUE){
                    $row_order = mysqli_fetch_assoc($result_order);
                  }
                  else{
                    echo 'data not fetched from order because ->' . mysqli_error($conn);
                  }


                // fetching from order details
                $get_orderdetails = "select * from order_details where order_id = $id_for_view";
                $result_orderdetails = mysqli_query($conn,$get_orderdetails);
                if($result_orderdetails == TRUE){
                    $row_orderdetails = mysqli_fetch_assoc($result_orderdetails);
                  }
                  else{
                    echo 'data not fetched from order details because ->' . mysqli_error($conn);
                  }

                // Printing Data
                echo '<p>'."Order ID : ".$row_customer['customer_id'].'</p>';

                echo '<p>'."Name : ".$row_customer['first_name']." ".$row_customer['last_name'].'</p>';
                
                echo '<p>'."Company Name : ".$row_customer['company_name'].'</p>';

                echo '<p>'."Order Date : ".$row_order['order_date'].'</p>';
            
                echo '<p>'."No of small bottles : ".$row_orderdetails['no_of_small_bottles'].'</p>';

                echo '<p>'."No of large bottles : ".$row_orderdetails['no_of_large_bottles'].'</p>';

                echo '<p>'."Total Price : ".$row_orderdetails['total_price'].'</p>';

                echo '<p>'."Discount : ".$row_orderdetails['discount'].'</p>';

                echo '<p>'."Total Payable : ".$row_orderdetails['total_payable'].'</p>';
                }
                else{
                    echo "<span>Sorry! Record Not Found</span>";
                }
                
            
}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
?>
   
</body>
</html>