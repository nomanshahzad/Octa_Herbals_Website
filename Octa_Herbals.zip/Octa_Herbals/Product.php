<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    echo "Connection was successfull";

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
// creating database
$create_table = 'CREATE TABLE Product( product_id INT NOT NULL AUTO_INCREMENT , product_name VARCHAR(45) NOT NULL ,employee_id INT NOT NULL , PRIMARY KEY (product_id), CONSTRAINT FK_emp_id FOREIGN KEY (employee_id)
REFERENCES employee(employee_id))';


$result = mysqli_query($conn,$create_table);
if($result == TRUE){
    echo 'Table is successfully created';
}
else{
    echo 'Table is not created beacause of error ->' . mysqli_error($conn);
}


?>