

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Octa Herbals</title>
    <link rel="stylesheet" href="octa.css">
    <link rel="stylesheet" href="login.css">
</head>
<body>

    <!-- Header -->
    <header class="header">
        <!-- Div for logo -->
    <div class="left">
    <img src="logo.png" alt="">
        <h3>Octa Herbals</h3>
    </div>
    <!-- Div for navbar -->
    <div class="mid">
        <ul class="navbar">
            <li><a href="home.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="orderform.php">Order</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>
    <!-- Div for button -->
    <div class="right">
    <button class="btn"><a href="https://web.facebook.com/OCTA-Herbal-Shampoo-102603767915346/">Like us on Facebook</a></button>
    </div>
    </header>

    <?php
$login = FALSE;
if(isset($_POST['submit'])){

    $servername = 'localhost';
    $username = 'Octa';
    $password = 'octa123';
    $database = 'octa_herbals';

    // connecting with mysql
    $conn = mysqli_connect($servername,$username,$password,$database);

    if($conn == TRUE){
       
    }
    else{
        die("Sorry we failed to connect : " . mysqli_connect_error());
    }    
    echo '<br>';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "select * from login where username = '$username' AND password = '$password'";
    $result = mysqli_query($conn,$sql);


    if($result==TRUE){
        $num = mysqli_num_rows($result);
        if($num == 1){
            $login = TRUE;
            session_start();
            $_SESSION['loggedin']= TRUE;
            header("location: welcome.php");
        }
        else{
            echo '<div class="alert alert-danger" role="alert">
            <strong>Invalid username or password!</strong>
          </div>';
    }
    }
    else{
        echo "data not fetched";
    }
    
   
}

?>


    <div class="loginform">
    <h1>Octa Herbals Login</h1>
        <form action="login.php" method="post">
            <div class="inp"><p>username : </p><input type="text" name="username" required></div>
            <div class="inp"><p>password : </p><input type="text" name="password" required></div>
           
             
            <input class="submit" type="submit" value="Log in" name="submit">
        
        </form>
    </div>
    
</body>
</html>