<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    echo "Connection was successfull";

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
// creating database
$create_table = 'CREATE TABLE order_details(total_price INT NOT NULL , discount INT NOT NULL , total_payable INT NOT NULL , no_of_small_bottles INT NOT NULL , no_of_large_bottles INT NOT NULL , order_id INT NOT NULL)';

$foreign_key = 'ALTER TABLE `order_details` ADD FOREIGN KEY (`order_id`) REFERENCES `order_table`(`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT';
$result = mysqli_query($conn,$create_table);

if($result == TRUE){
    echo 'Table is successfully created';
}
else{
    echo 'Table is not created beacause of error ->' . mysqli_error($conn);
}
$fresult = mysqli_query($conn,$foreign_key);
if($fresult == TRUE){
    echo 'Table is successfully updated';
}
else{
    echo 'Table is not updated beacause of error ->' . mysqli_error($conn);
}


?>