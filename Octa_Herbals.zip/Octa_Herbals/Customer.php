<?php

$servername = 'localhost';
$username = 'Octa';
$password = 'octa123';
$database = 'octa_herbals';

// connecting with mysql
$conn = mysqli_connect($servername,$username,$password,$database);

if($conn == TRUE){
    echo "Connection was successfull";

}
else{
    die("Sorry we failed to connect : " . mysqli_connect_error());
}    
echo '<br>';
// creating database
$create_table = 'CREATE TABLE customer ( customer_id INT NOT NULL AUTO_INCREMENT , first_name VARCHAR(45) NOT NULL , last_name VARCHAR(45) NOT NULL ,address VARCHAR(45) NOT NULL , email VARCHAR(45) NOT NULL , phone INT NOT NULL , company_name VARCHAR(45) NOT NULL , company_phone INT NOT NULL , product_id INT NOT NULL , PRIMARY KEY (customer_id), UNIQUE (email), UNIQUE (phone), CONSTRAINT FK_prdct_id FOREIGN KEY (product_id)
REFERENCES product(product_id))';


$result = mysqli_query($conn,$create_table);
if($result == TRUE){
    echo 'Table is successfully created';
}
else{
    echo 'Table is not created beacause of error ->' . mysqli_error($conn);
}


?>