if (empty($first_name)) {
  echo "<p>Please must enter First Name</p>.<br>";
}
elseif (empty($last_name)) {
  echo "<p>Please must enter your Last Name</p>.<br>";
}
elseif (empty($cnic)) {
  echo "<p>Please must enter your cnic</p>.<br>";
}
elseif (strlen($cnic) <> 13){
  echo "<p>Please enter a valid cnic number</p>";
}
elseif (empty($email)) {
  echo "<p>Please must enter yor email</p>.<br>";
}
elseif (empty($number)) {
  echo "<p>Please must enter yor number</p>.<br>";
}
elseif (strlen($number) <> 11){
  echo "<p>Please enter a validnumber</p>";
}
elseif (empty($address)) {
  echo "<p>Please must enter yor address</p>.<br>";
}
elseif (empty($date)) {
  echo "<p>Please must enter today's date</p>.<br>";
}
elseif (empty($no_of_small_bottles)) {
  echo "<p>Please must enter No of small bottles</p>.<br>";
}
elseif (empty($no_of_large_bottles)) {
  echo "<p>Please must enter No of large bottles</p>.<br>";
}
elseif (empty($id)) {
  echo "<p>Please must enter an ID</p>.<br>";
}
else{